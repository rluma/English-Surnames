﻿namespace English_Surnames
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.longerThanBtn = new System.Windows.Forms.Button();
            this.shorterThanBtn = new System.Windows.Forms.Button();
            this.beginWithBtn = new System.Windows.Forms.Button();
            this.fullBtn = new System.Windows.Forms.Button();
            this.longerTextBox = new System.Windows.Forms.TextBox();
            this.shorterTextBox = new System.Windows.Forms.TextBox();
            this.beginTextBox = new System.Windows.Forms.TextBox();
            this.fullTextBox = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.surnameListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // longerThanBtn
            // 
            this.longerThanBtn.Location = new System.Drawing.Point(12, 24);
            this.longerThanBtn.Name = "longerThanBtn";
            this.longerThanBtn.Size = new System.Drawing.Size(228, 23);
            this.longerThanBtn.TabIndex = 0;
            this.longerThanBtn.Text = "Find names longer than:";
            this.longerThanBtn.UseVisualStyleBackColor = true;
            this.longerThanBtn.Click += new System.EventHandler(this.longerThanBtn_Click);
            // 
            // shorterThanBtn
            // 
            this.shorterThanBtn.Location = new System.Drawing.Point(12, 75);
            this.shorterThanBtn.Name = "shorterThanBtn";
            this.shorterThanBtn.Size = new System.Drawing.Size(228, 23);
            this.shorterThanBtn.TabIndex = 1;
            this.shorterThanBtn.Text = "Find names shorter than:";
            this.shorterThanBtn.UseVisualStyleBackColor = true;
            this.shorterThanBtn.Click += new System.EventHandler(this.shorterThanBtn_Click);
            // 
            // beginWithBtn
            // 
            this.beginWithBtn.Location = new System.Drawing.Point(12, 126);
            this.beginWithBtn.Name = "beginWithBtn";
            this.beginWithBtn.Size = new System.Drawing.Size(228, 23);
            this.beginWithBtn.TabIndex = 2;
            this.beginWithBtn.Text = "Enter the first 3 characters of the surname:";
            this.beginWithBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.beginWithBtn.UseVisualStyleBackColor = true;
            this.beginWithBtn.Click += new System.EventHandler(this.beginWithBtn_Click);
            // 
            // fullBtn
            // 
            this.fullBtn.Location = new System.Drawing.Point(12, 174);
            this.fullBtn.Name = "fullBtn";
            this.fullBtn.Size = new System.Drawing.Size(228, 23);
            this.fullBtn.TabIndex = 3;
            this.fullBtn.Text = "Enter the full surname:";
            this.fullBtn.UseVisualStyleBackColor = true;
            this.fullBtn.Click += new System.EventHandler(this.fullBtn_Click);
            // 
            // longerTextBox
            // 
            this.longerTextBox.Location = new System.Drawing.Point(246, 24);
            this.longerTextBox.Name = "longerTextBox";
            this.longerTextBox.Size = new System.Drawing.Size(153, 20);
            this.longerTextBox.TabIndex = 4;
            // 
            // shorterTextBox
            // 
            this.shorterTextBox.Location = new System.Drawing.Point(246, 75);
            this.shorterTextBox.Name = "shorterTextBox";
            this.shorterTextBox.Size = new System.Drawing.Size(153, 20);
            this.shorterTextBox.TabIndex = 5;
            // 
            // beginTextBox
            // 
            this.beginTextBox.Location = new System.Drawing.Point(246, 126);
            this.beginTextBox.Name = "beginTextBox";
            this.beginTextBox.Size = new System.Drawing.Size(153, 20);
            this.beginTextBox.TabIndex = 6;
            // 
            // fullTextBox
            // 
            this.fullTextBox.Location = new System.Drawing.Point(246, 177);
            this.fullTextBox.Name = "fullTextBox";
            this.fullTextBox.Size = new System.Drawing.Size(153, 20);
            this.fullTextBox.TabIndex = 7;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(165, 491);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 8;
            this.button5.Text = "Close";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // surnameListBox
            // 
            this.surnameListBox.FormattingEnabled = true;
            this.surnameListBox.Location = new System.Drawing.Point(48, 228);
            this.surnameListBox.Name = "surnameListBox";
            this.surnameListBox.Size = new System.Drawing.Size(317, 251);
            this.surnameListBox.TabIndex = 9;
            this.surnameListBox.SelectedIndexChanged += new System.EventHandler(this.surnameListBox_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(416, 526);
            this.Controls.Add(this.surnameListBox);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.fullTextBox);
            this.Controls.Add(this.beginTextBox);
            this.Controls.Add(this.shorterTextBox);
            this.Controls.Add(this.longerTextBox);
            this.Controls.Add(this.fullBtn);
            this.Controls.Add(this.beginWithBtn);
            this.Controls.Add(this.shorterThanBtn);
            this.Controls.Add(this.longerThanBtn);
            this.Name = "Form1";
            this.Text = "English Surnames";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button longerThanBtn;
        private System.Windows.Forms.Button shorterThanBtn;
        private System.Windows.Forms.Button beginWithBtn;
        private System.Windows.Forms.Button fullBtn;
        private System.Windows.Forms.TextBox longerTextBox;
        private System.Windows.Forms.TextBox shorterTextBox;
        private System.Windows.Forms.TextBox beginTextBox;
        private System.Windows.Forms.TextBox fullTextBox;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ListBox surnameListBox;
    }
}

