﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace English_Surnames
{
    public partial class Form1 : Form
    {
        Dictionary<string, int> surnames = new Dictionary<string, int>();

        public Form1()
        {
            InitializeComponent();

            try
            {
                string[] sname = File.ReadAllLines("D:\\surnames.txt");
                for (int i = 0; i < sname.Length; i++)
                {
                    surnames[sname[i]] = i;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while reading the file: " + ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void longerThanBtn_Click(object sender, EventArgs e)
        {
            int n;
            if (int.TryParse(longerTextBox.Text, out n))
            {
                surnameListBox.Items.Clear();
                List<string> matchingSurnames = FindAll(s => s.Key.Length >= n);
                if (matchingSurnames.Count == 0)
                {
                    MessageBox.Show("No surnames exist greater than " + (n - 1) + " characters, please try entering a different number.");
                }
                foreach (string surname in matchingSurnames)
                {
                    surnameListBox.Items.Add(surname);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }

        private void shorterThanBtn_Click(object sender, EventArgs e)
        {
            int n;
            if (int.TryParse(shorterTextBox.Text, out n))
            {
                if (n <= 3)
                {
                    MessageBox.Show("No surnames exist matching this criteria, please try entering a greater number.");
                    return;
                }
                surnameListBox.Items.Clear();
                List<string> matchingSurnames = FindAll(s => s.Key.Length < n);
                foreach (string surname in matchingSurnames)
                {
                    surnameListBox.Items.Add(surname);
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }

        private void beginWithBtn_Click(object sender, EventArgs e)
        {
            string n = beginTextBox.Text.Trim();
            if (n.Length < 3)
            {
                MessageBox.Show("Please enter at least 3 letters.");
                return;
            }
            if (n.Substring(0, 3).Any(char.IsDigit))
            {
                MessageBox.Show("Please use letters instead of numbers.");
                return;
            }
            surnameListBox.Items.Clear();
            List<string> matchingSurnames = FindAll(s => s.Key.StartsWith(n, StringComparison.InvariantCultureIgnoreCase));
            foreach (string surname in matchingSurnames)
            {
                surnameListBox.Items.Add(surname);
            }
        }

        private void fullBtn_Click(object sender, EventArgs e)
        {
            string n = fullTextBox.Text.Trim();
            if (n.Any(char.IsDigit))
            {
                MessageBox.Show("Please input a valid surname.");
                return;
            }
            surnameListBox.Items.Clear();
            List<string> matchingSurnames = FindAll(s => s.Key.Equals(n, StringComparison.InvariantCultureIgnoreCase));
            foreach (string surname in matchingSurnames)
            {
                surnameListBox.Items.Add(surname);
            }
            if (matchingSurnames.Count == 0)
            {
                MessageBox.Show("The surname " + n + " cannot be found.");
            }
        }

        private void surnameListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedSurname = surnameListBox.SelectedItem.ToString();
            int selectedIndex = surnames[selectedSurname];
        }

        public List<string> FindAll(Func<KeyValuePair<string, int>, bool> predicate)
        {
            return surnames.Where(predicate).Select(s => s.Key).ToList();
        }
    }
}
